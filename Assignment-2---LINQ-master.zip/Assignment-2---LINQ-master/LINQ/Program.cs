﻿using System.Collections.Generic;
using System.Runtime.Intrinsics.X86;
using static LINQ.ListGenerator;
using static System.Net.Mime.MediaTypeNames;
namespace LINQ
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region LINQ - Element Operators

            #region 1. Get first Product out of Stock 
            //var result = ProductList.FirstOrDefault(p => p.UnitsInStock == 0);
            //Console.WriteLine(result);
            #endregion

            #region 2. Return the first product whose Price > 1000, unless there is no match, in which case null is returned.
            //var result = ProductList.FirstOrDefault(p => p.UnitPrice > 1000); 
            //Console.WriteLine(result);
            #endregion

            #region 3. Retrieve the second number greater than 5 
            //int[] Arr = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };

            //var result = Arr.Where(n => n > 5).Skip(1).FirstOrDefault();
            //Console.WriteLine(result);
            #endregion

            #endregion

            #region LINQ - Aggregate Operators

            #region 1. Uses Count to get the number of odd numbers in the array
            //int[] Arr = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };

            //var result = Arr.Count(a => a % 2 != 0);
            //Console.WriteLine(result);
            #endregion

            #region 2. Return a list of customers and how many orders each has.
            //var result = CustomerList.Select(c => new
            //{
            //    c.CustomerName,
            //    ordercount = c.Orders.Count()
            //});
            //foreach (var item in result)
            //  Console.WriteLine($"{item.CustomerName} - {item.ordercount}");
            #endregion

            #region 3. Return a list of categories and how many products each has
            //var result = ProductList.GroupBy(p=>p.Category).Select(c=> new
            //{
            //    Category = c.Key,
            //    countProduct = c.Count()
            //});
            //foreach (var item in result)
            //    Console.WriteLine($"{item.Category} - {item .countProduct}");
            #endregion

            #region 4. Get the total of the numbers in an array.
            //int[] Arr = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };

            //var result = Arr.Sum(n => n);
            //Console.WriteLine(result);
            #endregion

            #region Dictionary english [5:8 q]
            //string[] words = File.ReadAllLines("dictionary_english.txt");
            #region 5.Get the total number of characters of all words in dictionary_english.txt(Read dictionary_english.txt into Array of String First).
            //var totalChars = words.Sum(w => w.Length);
            //Console.WriteLine($"Total characters = {totalChars}");
            #endregion

            #region 6. Get the length of the shortest word in dictionary_english.txt (Read dictionary_english.txt into Array of String First).
            //var result = words.Min(w => w.Length);
            //Console.WriteLine(result);
            #endregion

            #region 7. Get the length of the longest word in dictionary_english.txt (Read dictionary_english.txt into Array of String First).
            //var result = words.Max(w => w.Length);
            //Console.WriteLine(result);
            #endregion

            #region 8. Get the average length of the words in dictionary_english.txt (Read dictionary_english.txt into Array of String First).
            //var result = words.Average(w => w.Length);
            //Console.WriteLine(result);
            #endregion

            #endregion

            #region 9. Get the total units in stock for each product category.
            //var result = ProductList.GroupBy(c => c.Category).Select(u => new
            //{
            //    Category = u.Key,
            //    TotalUnits = u.Sum(p=>p.UnitsInStock),
            //});

            //foreach (var item in result)
            //    Console.WriteLine($"{item.Category} - {item.TotalUnits}");

            #endregion

            #region 10. Get the cheapest price among each category's products
            //var result = ProductList.GroupBy(c => c.Category).Select(u => new
            //{
            //    Category = u.Key,
            //    CheapestPrice = u.Min(p=>p.UnitPrice),
            //});
            //foreach (var item in result)
            //    Console.WriteLine($"{item.Category} - {item.CheapestPrice}");

            #endregion

            #region 11. Get the products with the cheapest price in each category (Use Let)


            #endregion

            #region 12. Get the most expensive price among each category's products.
            //var result = ProductList.GroupBy(c => c.Category).Select(m => new
            //{
            //    Category = m.Key,
            //    ExpensiveProduct=m.Max(p=>p.UnitPrice)
            //});
            //foreach (var item in result)
            //    Console.WriteLine($"{item.Category} - {item.ExpensiveProduct}");
            #endregion

            #region 13. Get the products with the most expensive price in each category.
            //var result = ProductList.GroupBy(c=>c.Category).Select(p => new
            //{
            //    category = p.Key,
            //    expensiveProduct = p.Max(m=>m.UnitPrice),
            //});

            #endregion

            #region 14. Get the average price of each category's products.
            //var result = ProductList.GroupBy(c => c.Category).Select(avg => new
            //{
            //    Category = avg.Key,
            //    AvragePrice = avg.Average(p => p.UnitPrice)
            //});
            //foreach (var item in result)
            //    Console.WriteLine($"{item.Category} - {item.AvragePrice}");
            #endregion

            #endregion

            #region LINQ - Set Operators

            #region 1. Find the unique Category names from Product List
            //var result = (from c in ProductList
            //             select c.Category).Distinct();

            //foreach (var c in result)
            //    Console.WriteLine(c);
            #endregion

            #region 2. Produce a Sequence containing the unique first letter from both product and customer names.
            //var result = (from p in ProductList
            //              select p.ProductName[0])
            //             .Union
            //             (from c in CustomerList
            //              select c.CustomerName[0]).OrderBy(c => c);

            //foreach (var ch in result)
            //    Console.WriteLine(ch);
            #endregion

            #region 3. Create one sequence that contains the common first letter from both product and customer names.
            //var result = (from p in ProductList
            //              select p.ProductName[0])
            //             .Intersect
            //             (from c in CustomerList
            //              select c.CustomerName[0]).OrderBy(c => c);

            //foreach (var ch in result)
            //    Console.WriteLine(ch);
            #endregion

            #region 4. Create one sequence that contains the first letters of product names that are not also first letters of customer names.
            //var result = (from p in ProductList
            //              select p.ProductName[0])
            //             .Except
            //             (from c in CustomerList
            //              select c.CustomerName[0]).OrderBy(c => c);

            //foreach (var ch in result)
            //    Console.WriteLine(ch); 
            #endregion

            #region 5. Create one sequence that contains the last Three Characters in each name of all customers and products, including any duplicates
            //var result = (from c in CustomerList
            //              select c.CustomerName.TakeLast(3).ToArray())
            //             .Concat
            //             (from p in ProductList
            //              select p.ProductName.TakeLast(3).ToArray());

            //foreach (var c in result)
            //    Console.WriteLine(c);
            #endregion

            #endregion

            #region LINQ - Quantifiers

            #region 1. Determine if any of the words in dictionary_english.txt (Read dictionary_english.txt into Array of String First) contain the substring 'ei'.
            //string[] words = File.ReadAllLines("dictionary_english.txt");

            //var result = words.Any(w => w.Contains("ei"));

            //Console.WriteLine(result);
            #endregion

            #region 2. Return a grouped a list of products only for categories that have at least one product that is out of stock.
            //var result = from p in ProductList
            //             group p by p.Category
            //             into c
            //             where c.Any(c => c.UnitsInStock == 0)
            //             select new
            //             {
            //                 category =c.Key,
            //                 products =c.ToList()
            //             };

            //foreach (var group in result)
            //{
            //    Console.WriteLine($"Category: {group.category}");
            //    foreach (var c in group.products)
            //        Console.WriteLine(c.ProductName+ " - " + c.UnitsInStock);
            //}
            #endregion

            #region 3. Return a grouped list of products only for categories that have all of their products in stock.
            //var result = from p in ProductList
            //             group p by p.Category into c
            //             where c.All(p => p.UnitsInStock > 0)   
            //             select new
            //             {
            //                 category = c.Key,
            //                 products = c.ToList()
            //             };

            //foreach (var group in result)
            //{
            //    Console.WriteLine($"Category: {group.category}");
            //    foreach (var c in group.products)
            //    {
            //        Console.WriteLine($"   {c.ProductName} -  {c.UnitsInStock}");
            //    }
            //}
            #endregion

            #endregion

            #region LINQ – Grouping Operators

            #region 1- Use group by to partition a list of numbers by their remainder when divided by 5

            //List<int> numbers = new List<int> { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };

            //var result = from n in numbers
            //             group n by n % 5 into g
            //             select g;

            //foreach (var group in result)
            //{
            //    Console.WriteLine($"Numbers with remainder of {group.Key} when divided by 5:");
            //    foreach (var num in group)
            //    {
            //        Console.WriteLine($"{num}");
            //    }
            //} 
            #endregion

            #region Uses group by to partition a list of words by their first letter.Use dictionary_english.txt for Input
            //string[] words = File.ReadAllLines("dictionary_english.txt");

            //var result = from w in words
            //             group w by w[0] into g
            //             orderby g.Key
            //             select g;

            //foreach (var group in result)
            //{
            //    Console.WriteLine($"Words starting with '{group.Key}':");
            //    foreach (var word in group)
            //    {
            //        Console.WriteLine($"   {word}");
            //    }
            //}

            #endregion

            #region Use Group By with a custom comparer that matches words that are consists of the same Characters Together
            //string[] Arr = { "from", "salt", "earn", "last", "near", "form" };

            //var result = Arr.GroupBy(word => new string(word.OrderBy(ch => ch).ToArray()));

            //foreach (var group in result)
            //{
            //    Console.WriteLine($"Group ({group.Key}):");
            //    foreach (var word in group)
            //    {
            //        Console.WriteLine($"   {word}");
            //    }
            //}
            #endregion

            #endregion
        }
    }
}
